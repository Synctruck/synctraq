<?php
namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Models\{ PalletDispatch };

use Illuminate\Support\Facades\Validator;

use Auth;
use DB;
use Session;

class PalletDispatchController extends Controller
{
    public function List($dateStart, $dateEnd)
    {
        $palletList = PalletDispatch::orderBy('created_at', 'desc')->paginate(50);
        
        return ['palletList' => $palletList];
    }

    public function Insert(Request $request)
    {
        $validator = Validator::make($request->all(),

            [
                "Route" => ["required"],
            ],
            [
                "Route.required" => "You must select a route",
            ]
        );

        if($validator->fails())
        {
            return response()->json(["status" => 422, "errors" => $validator->errors()], 422);
        }

        $pallet = new PalletDispatch();

        $pallet->number = date('YmdHis') .'-'. Auth::user()->id;
        $pallet->idUser = Auth::user()->id;
        $pallet->Route  = $request->get('Route');
        $pallet->status = 'Opened';

        $pallet->save();

        return ['stateAction' => true];
    }
}