@extends('layout.admin')
@section('title', 'Inicio')
@section('content')
<div id="home">
</div>
@endsection