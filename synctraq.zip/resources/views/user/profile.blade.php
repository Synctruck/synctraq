@extends('layout.admin')
@section('title', 'User - Change Password')
@section('content')
<div class="pagetitle">
  	<h1><b>PROFILE</b></h1>
  	<nav>
    	<ol class="breadcrumb">
			<li class="breadcrumb-item"><a href="#">Home</a></li>
			<li class="breadcrumb-item active">Profile</li>
    	</ol>
  	</nav>
</div><!-- End Page Title -->

<div id="userProfile">
</div>
@endsection
