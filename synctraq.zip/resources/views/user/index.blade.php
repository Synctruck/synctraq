@extends('layout.admin')
@section('title', 'Users Maintenance')
@section('content')
<div class="pagetitle">
  	<h1>Users Maintenance</h1>
  	<nav>
    	<ol class="breadcrumb">
			<li class="breadcrumb-item"><a href="#">Home</a></li>
			<li class="breadcrumb-item active">Users</li>
    	</ol>
  	</nav>
</div><!-- End Page Title -->

<div id="user">
</div>
@endsection