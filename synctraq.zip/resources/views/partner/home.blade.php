@extends('layout.partner')
@section('title', 'Inicio')
@section('content')
<div id="home">
</div>
@endsection
