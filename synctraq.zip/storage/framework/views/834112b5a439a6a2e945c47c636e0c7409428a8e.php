
<?php $__env->startSection('title', 'Packages - Returns'); ?>
<?php $__env->startSection('content'); ?>
<div class="pagetitle">
  	<h1><b>PACKAGES - RETURNS</b></h1>
  	<nav>
    	<ol class="breadcrumb">
			<li class="breadcrumb-item"><a href="#">Home</a></li>
			<li class="breadcrumb-item active">Packages Returns</li>
    	</ol>
  	</nav>
</div><!-- End Page Title -->
<script>
	let auxDateInit = '<?php echo e(date('Y-m-d')); ?>';
	let auxDateEnd  = '<?php echo e(date('Y-m-d')); ?>';
</script>
<div id="packageReturn">
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\synctraq\resources\views/package/return.blade.php ENDPATH**/ ?>