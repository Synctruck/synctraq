
<?php $__env->startSection('title', 'Reports - All'); ?>
<?php $__env->startSection('content'); ?>
<div class="pagetitle">
  	<h1><b>ROLES</b></h1>
  	<nav>
    	<ol class="breadcrumb">
			<li class="breadcrumb-item"><a href="#">Home</a></li>
			<li class="breadcrumb-item active">Roles</li>
    	</ol>
  	</nav>
</div><!-- End Page Title -->
<script>
	let auxDateInit = '<?php echo e(date('Y-m-d')); ?>';
	let auxDateEnd  = '<?php echo e(date('Y-m-t')); ?>';
</script>
<div id="roles">
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\synctraq\resources\views/role/index.blade.php ENDPATH**/ ?>