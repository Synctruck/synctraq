

<?php $__env->startSection('title', __('Forbidden')); ?>
<?php $__env->startSection('code'); ?>
<h1>403</h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('message'); ?>
<h1>You do not have permission to access this section, please contact the administrator</h1>

<a href="/" class="btn btn-success"> Back to login</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('errors::minimal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\synctraq\resources\views/errors/403.blade.php ENDPATH**/ ?>