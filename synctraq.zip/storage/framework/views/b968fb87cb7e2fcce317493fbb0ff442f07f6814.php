
<?php $__env->startSection('title', 'Driver Maintenance'); ?>
<?php $__env->startSection('content'); ?>
<div class="pagetitle">
  	<h1>Driver Maintenance</h1>
  	<nav>
    	<ol class="breadcrumb">
			<li class="breadcrumb-item"><a href="#">Home</a></li>
			<li class="breadcrumb-item active">Drivers</li>
    	</ol>
  	</nav>
</div><!-- End Page Title -->
<script>
	let idUserGeneral = '<?php echo e(Auth::user()->id); ?>';
</script>
<div id="driver">
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\synctraq\resources\views/driver/index.blade.php ENDPATH**/ ?>