
<?php $__env->startSection('title', 'Inicio'); ?>
<?php $__env->startSection('content'); ?>
<div id="home">
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.partner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\synctraq\resources\views/partner/home.blade.php ENDPATH**/ ?>