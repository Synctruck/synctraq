
<?php $__env->startSection('title', 'Route Maintenance'); ?>
<?php $__env->startSection('content'); ?>
<div class="pagetitle">
  	<h1>Route Maintenance</h1>
  	<nav>
    	<ol class="breadcrumb">
			<li class="breadcrumb-item"><a href="#">Home</a></li>
			<li class="breadcrumb-item active">Routes</li>
    	</ol>
  	</nav>
</div><!-- End Page Title -->

<div id="routes">
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\synctraq\resources\views/routes/index.blade.php ENDPATH**/ ?>