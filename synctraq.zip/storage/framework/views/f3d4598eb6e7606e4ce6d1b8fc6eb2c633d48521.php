
<?php $__env->startSection('title', 'REPORTS -  Delivery'); ?>
<?php $__env->startSection('content'); ?>
<div class="pagetitle">
  	<h1><b>REPORTS -  DELIVERY</b></h1>
  	<nav>
    	<ol class="breadcrumb">
			<li class="breadcrumb-item"><a href="#">Home</a></li>
			<li class="breadcrumb-item active">Reports Delivery</li>
    	</ol>
  	</nav>
</div><!-- End Page Title -->
<script>
	let idUserGeneral = '<?php echo e(Auth::user()->id); ?>';
	let auxDateInit   = '<?php echo e(date('Y-m-d')); ?>';
	let auxDateEnd    = '<?php echo e(date('Y-m-t')); ?>';
    let auth = <?php echo json_encode(Auth::user(), 15, 512) ?>;
    var id_team = 0;
    var id_driver = 0;
        if(auth.idRole == 4){
            id_team = auth.idTeam
            id_driver = auth.id;
        }
        if(auth.idRole == 3){
            id_team = auth.id
        }
        console.log(id_team,id_driver)

</script>
<div id="reportDelivery">
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\synctraq\resources\views/report/indexdelivery.blade.php ENDPATH**/ ?>