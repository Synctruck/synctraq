
<?php $__env->startSection('title', 'Reportes - Dispatch'); ?>
<?php $__env->startSection('content'); ?>
<div class="pagetitle">
  	<h1>Reportes - Dispatch</h1>
  	<nav>
    	<ol class="breadcrumb">
			<li class="breadcrumb-item"><a href="#">Inicio</a></li>
			<li class="breadcrumb-item active">Reportes Dispatch</li>
    	</ol>
  	</nav>
</div><!-- End Page Title -->
<script>
	let idUserGeneral = '<?php echo e(Auth::user()->id); ?>';
	let auxDateInit   = '<?php echo e(date('Y-m-d')); ?>';
	let auxDateEnd    = '<?php echo e(date('Y-m-t')); ?>';
</script>
<div id="reportDispatch">
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\synctraq\resources\views/report/indexdispatch.blade.php ENDPATH**/ ?>