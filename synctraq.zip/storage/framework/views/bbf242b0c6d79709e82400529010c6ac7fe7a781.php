
<?php $__env->startSection('title', 'User - Change Password'); ?>
<?php $__env->startSection('content'); ?>
<div class="pagetitle">
  	<h1>Profile</h1>
  	<nav>
    	<ol class="breadcrumb">
			<li class="breadcrumb-item"><a href="#">Home</a></li>
			<li class="breadcrumb-item active">Profile</li>
    	</ol>
  	</nav>
</div><!-- End Page Title -->

<div id="userProfile">
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\synctraq\resources\views/user/profile.blade.php ENDPATH**/ ?>