
<?php $__env->startSection('title', 'Packages - Dispatch'); ?>
<?php $__env->startSection('content'); ?>
<div class="pagetitle">
  	<h1><b>PACKAGES - DISPATCH</b></h1>
  	<nav>
    	<ol class="breadcrumb">
			<li class="breadcrumb-item"><a href="#">Home</a></li>
			<li class="breadcrumb-item active">Packages</li>
    	</ol>
    	<?php

			$routesTeamGeneral = '';

		?>

    	<?php if(count(Auth::user()->routes_team) > 0): ?>
    		<?php $__currentLoopData = Auth::user()->routes_team; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $routeTeam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    			<?php

    				$routesTeamGeneral = $routesTeamGeneral == '' ? $routeTeam->route->name : $routesTeamGeneral .'|'. $routeTeam->route->name;
    			?>
    		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    	<?php endif; ?>
  	</nav>
</div><!-- End Page Title -->
<script>
	let idUserGeneral     = '<?php echo e(Auth::user()->id); ?>';
	let routesTeamGeneral = '<?php echo e($routesTeamGeneral); ?>';
</script>
<script>
	let auxDateInit = '<?php echo e(date('Y-m-d')); ?>';
	let auxDateEnd  = '<?php echo e(date('Y-m-t')); ?>';
</script>
<div id="packageDispatch">
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\synctraq\resources\views/package/dispatch.blade.php ENDPATH**/ ?>