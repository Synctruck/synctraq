
<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>
<div class="pagetitle">
  	<h1><b>DASHBOARD</b></h1>
  	<nav>
    	<ol class="breadcrumb">
			<li class="breadcrumb-item"><a href="#">Home</a></li>
			<li class="breadcrumb-item active">Dashboard</li>
    	</ol>
  	</nav>
</div><!-- End Page Title -->
<script>
	let auxDateStart = '<?php echo e(date('Y-m-d')); ?>';
	let auxDateEnd  = '<?php echo e(date('Y-m-t')); ?>';
</script>
<div id="partnerDashboard">
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.partner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\synctraq\resources\views/partner/dashboard.blade.php ENDPATH**/ ?>