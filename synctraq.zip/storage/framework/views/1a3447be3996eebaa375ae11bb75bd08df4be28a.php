<aside id="sidebar" class="sidebar">
    <ul class="sidebar-nav" id="sidebar-nav">
        <li >
            <div id="google_translate_element" class="google"></div>
        </li>

        <li class="nav-heading"></li>
        <li >
            <a class="nav-link <?php echo e(Request::is('package-blocked') ? 'active' : 'collapsed'); ?>" href="<?php echo e(url('package-blocked')); ?>">
                <i class="bx bx-block"></i>
                <span>PACKAGE BLOCKED</span>
            </a>
        </li>
            <?php if(hasPermission('dashboard.index')): ?>
                <li class="nav-heading"></li>
                <li >
                    <a class="nav-link <?php echo e(Request::is('dashboard') ? 'active' : 'collapsed'); ?>" href="<?php echo e(url('dashboard')); ?>">
                        <i class="bx bxs-dashboard"></i>
                        <span>DASHBOARD</span>
                    </a>
                </li>
            <?php endif; ?>
            <?php if(hasPermission('manifest.index')): ?>
                <li >
                    <a class="nav-link <?php echo e(Request::is('package-manifest') ? 'active' : 'collapsed'); ?>" href="<?php echo e(url('package-manifest')); ?>">
                        <i class="bx bxs-box"></i>
                        <span>MANIFEST</span>
                    </a>
                </li>
            <?php endif; ?>

                
            <?php if(hasPermission('inbound.index')): ?>
                <li >
                    <a class="nav-link <?php echo e(Request::is('package-inbound') ? 'show' : 'collapsed'); ?>" href="<?php echo e(url('/package-inbound')); ?>">
                        <i class="bx bx-barcode-reader"></i>
                        <span>INBOUND</span>
                    </a>
                </li>
            <?php endif; ?>

            <?php if(hasPermission('dispatch.index')): ?>
                <li >
                    <a class="nav-link <?php echo e(Request::is('package-dispatch') ? 'show' : 'collapsed'); ?>" href="<?php echo e(url('/package-dispatch')); ?>">
                        <i class="bx bx-car"></i>
                        <span>DISPATCH</span>
                    </a>
                </li>
            <?php endif; ?>

            <?php if(hasPermission('checkstop.index')): ?>
                <li >
                    <a class="nav-link <?php echo e(Request::is('package-check') ? 'show' : 'collapsed'); ?>" href="<?php echo e(url('/package-check')); ?>">
                        <i class="bx bx-barcode-reader"></i>
                        <span>CHECK STOP</span>
                    </a>
                </li>
            <?php endif; ?>

                

                <li style="display: none;">
                    <a class="nav-link <?php echo e(Request::is('package-delivery') ? 'show' : 'collapsed'); ?>" href="<?php echo e(url('package-delivery')); ?>">
                        <i class="bx bx-car"></i>
                        <span>DELIVERIES</span>
                    </a>
                </li>




                
                

            <?php if(hasPermission('reinbound.index')): ?>
                <li >
                    <a class="nav-link <?php echo e(Request::is('package/return') ? 'show' : 'collapsed'); ?>" href="<?php echo e(url('/package/return')); ?>">
                        <i class="bx bx-car"></i>
                        <span>RE-INBOUND</span>
                    </a>
                </li>
            <?php endif; ?>

            <?php if(hasPermission('warehouse.index')): ?>
                <li >
                    <a class="nav-link <?php echo e(Request::is('package-warehouse') ? 'show' : 'collapsed'); ?>" href="<?php echo e(url('/package-warehouse')); ?>">
                        <i class="bx bx-car"></i>
                        <span>WAREHOUSE</span>
                    </a>
                </li>
            <?php endif; ?>

                


            <?php if(hasPermission('assigned.index')): ?>
            <li >
                <a class="nav-link <?php echo e(Request::is('assignedTeam') ? 'show' : 'collapsed'); ?>" href="<?php echo e(url('/assignedTeam')); ?>">
                    <i class="bx bx-user"></i>
                    <span>ASSIGNED</span>
                </a>
            </li>
            <?php endif; ?>
            <?php if(hasPermission('unssigned.index')): ?>
            <li >
                <a class="nav-link <?php echo e(Request::is('unassignedTeam') ? 'show' : 'collapsed'); ?>" href="<?php echo e(url('/unassignedTeam')); ?>">
                    <i class="bx bx-user"></i>
                    <span>UNSSIGNED</span>
                </a>
            </li>
            <?php endif; ?>

                <li class="nav-heading" id="titleReports" >Reports</li>
                <li class="nav-item" id="liUlReports">
                    <a class="nav-link
                            <?php echo e(Request::is('report/failed') ||
                                Request::is('report/assigns') ||
                                Request::is('report/dispatch') ||
                                Request::is('report/delivery') ||
                                Request::is('report/inbound') ||
                                Request::is('report/manifest') ||
                                Request::is('report/notExists') ||
                                Request::is('report/return-company')
                                ?
                                    ''
                                :
                                    'collapsed'); ?>" data-bs-target="#ulReports" data-bs-toggle="collapse" href="#"
                    >
                        <i class="bi bi-journal-text"></i><span>GENERAL REPORTS</span><i class="bi bi-chevron-down ms-auto"></i>
                    </a>
                    <ul id="ulReports" class="nav-content
                            <?php echo e(Request::is('report/failed') ||
                                Request::is('report/assigns') ||
                                Request::is('report/dispatch') ||
                                Request::is('report/delivery') ||
                                Request::is('report/inbound') ||
                                Request::is('report/manifest') ||
                                Request::is('report/notExists') ||
                                Request::is('report/return-company')
                                ?
                                    'collapse show'
                                :
                                    'collapse'); ?>" data-bs-parent="#ulReports"
                    >
                    <?php if(hasPermission('reportManifest.index')): ?>
                        <li>
                            <a class="nav-link <?php echo e(Request::is('report/manifest') ? 'show' : 'collapsed'); ?>" href="<?php echo e(url('/report/manifest')); ?>">
                                <i class="bx bxs-report"></i>
                                <span>Manifest</span>
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if(hasPermission('reportInbound.index')): ?>
                        <li>
                            <a class="nav-link <?php echo e(Request::is('report/inbound') ? 'show' : 'collapsed'); ?>" href="<?php echo e(url('/report/inbound')); ?>">
                                <i class="bx bxs-report"></i>
                                <span>Inbound</span>
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if(hasPermission('reportDispatch.index')): ?>
                        <li>
                            <a class="nav-link <?php echo e(Request::is('report/dispatch') ? 'show' : 'collapsed'); ?>" href="<?php echo e(url('/report/dispatch')); ?>">
                                <i class="bx bxs-report"></i>
                                <span>Dispatch</span>
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if(hasPermission('reportDelivery.index')): ?>
                        
                        <li>
                            <a class="nav-link <?php echo e(Request::is('report/delivery') ? 'show' : 'collapsed'); ?>" href="<?php echo e(url('/report/delivery')); ?>">
                                <i class="bx bxs-report"></i>
                                <span>Delivery</span>
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if(hasPermission('reportNotexists.index')): ?>
                        
                        <li>
                            <a class="nav-link <?php echo e(Request::is('report/notExists') ? 'show' : 'collapsed'); ?>" href="<?php echo e(url('/report/notExists')); ?>">
                                <i class="bx bxs-report"></i>
                                <span>Not Exists</span>
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if(hasPermission('reportReturncompany.index')): ?>
                        <li>
                            <a class="nav-link <?php echo e(Request::is('report/return-company') ? 'show' : 'collapsed'); ?>" href="<?php echo e(url('/report/return-company')); ?>">
                                <i class="bx bxs-report"></i>
                                <span>Return Company</span>
                            </a>
                        </li>
                    <?php endif; ?>

                    </ul>
                </li>


                <li class="nav-heading" id="titleMaintenances">MAINTENANCES</li>
                <li class="nav-item" id="liUlUsers">
                    <a class="nav-link <?php echo e((Request::is('user') || Request::is('team') || Request::is('driver') || Request::is('validator')   || Request::is('viewer') || Request::is('roles') ) ? '' : 'collapsed'); ?>" data-bs-target="#ulUsers" data-bs-toggle="collapse" href="#" aria-expanded=" <?php echo e(Request::is('team') ? 'true' : 'false'); ?>">
                      <i class="bi bi-person"></i><span>USERS GENERAL</span><i class="bi bi-chevron-down ms-auto"></i>
                    </a>
                    <ul id="ulUsers" class="nav-content collapse <?php echo e(Request::is('user') || Request::is('team') || Request::is('roles') || Request::is('driver') || Request::is('validator')   || Request::is('viewer')? 'show' : ''); ?>" data-bs-parent="#ulUsers" style="">

                        <?php if(hasPermission('admin.index')): ?>
                        <li >
                            <a class="nav-link <?php echo e(Request::is('user') ? 'show' : 'collapsed'); ?>" href="<?php echo e(url('user')); ?>">
                                <i class="bi bi-person"></i>
                                <span>Admins</span>
                            </a>
                        </li>
                        <?php endif; ?>

                        <?php if(hasPermission('team.index')): ?>
                        <li >
                            <a class="nav-link <?php echo e(Request::is('team') ? 'active' : 'collapsed'); ?>" href="<?php echo e(url('team')); ?>">
                                <i class="bi bi-person"></i>
                                <span>Teams</span>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if(hasPermission('driver.index')): ?>
                        <li >
                            <a class="nav-link <?php echo e(Request::is('driver') ? 'active' : 'collapsed'); ?>" href="<?php echo e(url('driver')); ?>">
                                <i class="bi bi-person"></i>
                                <span>Drivers</span>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if(hasPermission('viewer.index')): ?>
                        <li >
                            <a class="nav-link <?php echo e(Request::is('viewer') ? 'active' : 'collapsed'); ?>" href="<?php echo e(url('viewer')); ?>">
                                <i class="bi bi-person"></i>
                                <span>Viewers</span>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if(hasPermission('validator.index')): ?>
                        <li >
                            <a class="nav-link <?php echo e(Request::is('validator') ? 'active' : 'collapsed'); ?>" href="<?php echo e(url('validator')); ?>">
                                <i class="bi bi-person"></i>
                                <span>Validators</span>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if(hasPermission('role.index')): ?>
                        <li >
                            <a class="nav-link <?php echo e(Request::is('roles') ? 'active' : 'collapsed'); ?>" href="<?php echo e(url('roles')); ?>">
                                <i class="bi bi-person"></i>
                                <span>Roles</span>
                            </a>
                        </li>
                        <?php endif; ?>
                    </ul>
                </li>

                <li class="nav-item" id="liUlConfiguration">
                    <a class="nav-link <?php echo e((Request::is('routes') || Request::is('comments') || Request::is('company') || Request::is('anti-scan')) ? '' : 'collapsed'); ?>" data-bs-target="#ulConfiguration" data-bs-toggle="collapse" href="#" aria-expanded=" <?php echo e(Request::is('routes') || Request::is('comments') || Request::is('company') || Request::is('anti-scan') ? 'true' : 'false'); ?>">
                      <i class="bi bi-person"></i><span>CONFIGURATION GENERAL</span><i class="bi bi-chevron-down ms-auto"></i>
                    </a>
                    <ul id="ulConfiguration" class="nav-content collapse <?php echo e((Request::is('routes') || Request::is('comments') || Request::is('company') || Request::is('anti-scan'))? 'show' : ''); ?>" data-bs-parent="#ulConfiguration" style="">

                        <?php if(hasPermission('route.index')): ?>
                        <li >
                            <a class="nav-link <?php echo e(Request::is('routes') ? 'show' : 'collapsed'); ?>" href="<?php echo e(url('routes')); ?>">
                                <i class="bx bx-command"></i>
                                <span>Routes</span>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if(hasPermission('comment.index')): ?>
                        <li >
                            <a class="nav-link <?php echo e(Request::is('comments') ? 'active' : 'collapsed'); ?>" href="<?php echo e(url('comments')); ?>">
                                <i class="bx bxs-message"></i>
                                <span>Comments</span>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if(hasPermission('company.index')): ?>
                            <li >
                                <a class="nav-link <?php echo e(Request::is('company') ? 'show' : 'collapsed'); ?>" href="<?php echo e(url('company')); ?>">
                                    <i class="bx bx-home-alt"></i>
                                    <span>Companies</span>
                                </a>
                            </li>
                        <?php endif; ?>

                        <?php if(hasPermission('antiscan.index')): ?>
                        <li>
                            <a class="nav-link <?php echo e(Request::is('anti-scan') ? 'active' : 'collapsed'); ?>" href="<?php echo e(url('anti-scan')); ?>">
                                <i class="bx bxs-notification-off"></i>
                                <span>Anti-Scan</span>
                            </a>
                        </li>
                        <?php endif; ?>
                    </ul>
                </li>

                <li class="nav-item" id="liUlFinanzas">
                    <a class="nav-link <?php echo e((Request::is('package-delivery/finance') || Request::is('package-delivery/check')) ? '' : 'collapsed'); ?>" data-bs-target="#ulFinanzas" data-bs-toggle="collapse" href="#" aria-expanded=" <?php echo e(Request::is('package-delivery/finance') || Request::is('package-delivery/check') ? 'true' : 'false'); ?>">
                      <i class="bx bxs-check-circle"></i><span>FINANZAS</span><i class="bi bi-chevron-down ms-auto"></i>
                    </a>
                    <ul id="ulFinanzas" class="nav-content collapse <?php echo e((Request::is('package-delivery/check') || Request::is('package-delivery/finance') || Request::is('company') || Request::is('anti-scan'))? 'show' : ''); ?>" data-bs-parent="#ulFinanzas" style="">
                        <?php if(hasPermission('checkDelivery.index')): ?>
                        <li >
                            <a class="nav-link <?php echo e(Request::is('package-delivery/check') ? 'show' : 'collapsed'); ?>" href="<?php echo e(url('/package-delivery/check')); ?>">
                                <i class="bx bxs-check-circle"></i>
                                <span>CHECK - UNCHECK DELIVERY</span>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if(hasPermission('validatedDelivery.index')): ?>
                            <li>
                                <a class="nav-link <?php echo e(Request::is('package-delivery/finance') ? 'active' : 'collapsed'); ?>" href="<?php echo e(url('package-delivery/finance')); ?>">
                                    <i class="bx bxs-dollar-circle"></i>
                                    <span>VALIDATE DELIVERY</span>
                                </a>
                            </li>
                        <?php endif; ?>
                    </ul>
                </li>

            

    </ul>
</aside><!-- End Sidebar-->
<?php /**PATH C:\xampp\htdocs\synctraq\resources\views/layout/sidebar.blade.php ENDPATH**/ ?>