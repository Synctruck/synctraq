
<?php $__env->startSection('title', 'REPORTS -  Failed'); ?>
<?php $__env->startSection('content'); ?>
<div class="pagetitle">
  	<h1><b>REPORT - FAILED</b></h1>
  	<nav>
    	<ol class="breadcrumb">
			<li class="breadcrumb-item"><a href="#">Home</a></li>
			<li class="breadcrumb-item active">Reports Failed</li>
    	</ol>
  	</nav>
</div><!-- End Page Title -->
<script>
	let auxDateInit   = '<?php echo e(date('Y-m-d')); ?>';
	let auxDateEnd    = '<?php echo e(date('Y-m-t')); ?>';
    var id_team = 0;
    var id_driver = 0;

</script>
<div id="reportPartnerFailed">
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.partner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\synctraq\resources\views/partner/report/failed.blade.php ENDPATH**/ ?>