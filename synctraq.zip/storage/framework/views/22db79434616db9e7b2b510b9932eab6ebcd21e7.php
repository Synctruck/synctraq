
<?php $__env->startSection('title', 'State Maintenance'); ?>
<?php $__env->startSection('content'); ?>
<div class="pagetitle">
  	<h1>State Maintenance</h1>
  	<nav>
    	<ol class="breadcrumb">
			<li class="breadcrumb-item"><a href="#">Home</a></li>
			<li class="breadcrumb-item active">States</li>
    	</ol>
  	</nav>
</div><!-- End Page Title -->

<div id="states">
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\synctraq\resources\views/states/index.blade.php ENDPATH**/ ?>