
<?php $__env->startSection('title', 'Package - Unassigned'); ?>
<?php $__env->startSection('content'); ?>
<div class="pagetitle">
  	<h1>Package - Unassigned</h1>
  	<nav>
    	<ol class="breadcrumb">
			<li class="breadcrumb-item"><a href="#">Home</a></li>
			<li class="breadcrumb-item active">Unassigned</li>
    	</ol>
  	</nav>
</div><!-- End Page Title -->
<script>
	let idUserGeneral     = '<?php echo e(Auth::user()->id); ?>';
</script>
<div id="unassignedTeam">
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\synctraq\resources\views/package/unassignedteam.blade.php ENDPATH**/ ?>